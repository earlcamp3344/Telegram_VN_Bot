# Copy entire content of cloud_bot.py
import os
import logging
import requests
import json
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes, ConversationHandler
from dotenv import load_dotenv
from google.oauth2 import service_account
from googleapiclient.discovery import build
from notion_client import Client
import google_auth_oauthlib.flow
import tempfile
import pytz
import nltk
from nltk.tokenize import word_tokenize
from nltk.tag import pos_tag
import re
from dateutil import parser as date_parser
from vosk import Model, KaldiRecognizer
import wave
import io
from aiohttp_socks import ProxyConnector
from pydub import AudioSegment
import subprocess

# Rest of the cloud_bot.py content...
# ... existing code ... 